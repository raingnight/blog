package top.fx7.yinlu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YinluApplicationTests {

    @Test
    void contextLoads() {
    }

}
