package top.fx7.yinlu.service;


import com.baomidou.mybatisplus.extension.service.IService;
import top.fx7.yinlu.model.Diary;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author 人家故里
 * @since 2020-08-15
 */
public interface IDiaryService extends IService<Diary> {

    List<Diary> getDiaries();

    int addDiary(Diary diary);
}
