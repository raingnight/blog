package top.fx7.yinlu.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import top.fx7.yinlu.mapper.DiaryMapper;
import top.fx7.yinlu.model.Diary;
import top.fx7.yinlu.service.IDiaryService;

import java.util.List;

@Service
public class DiaryServiceImpl extends ServiceImpl<DiaryMapper, Diary> implements IDiaryService {
    @Autowired
    DiaryMapper diaryMapper;

    @Override
    public List<Diary> getDiaries() {
        List<Diary> diaries = diaryMapper.getDiaries();
        return diaries;
    }

    @Override
    public int addDiary(Diary diary) {
        int rows = diaryMapper.insertDiary(diary);
        return rows;
    }

    public int updateViewCount(Integer id) {
        int rows = diaryMapper.updateViewCount(id);
        return rows;
    }
}
