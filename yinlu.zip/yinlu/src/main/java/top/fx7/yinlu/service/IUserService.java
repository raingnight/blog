package top.fx7.yinlu.service;

import org.springframework.security.core.userdetails.UserDetails;
import top.fx7.yinlu.model.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 人家故里
 * @since 2020-08-15
 */
public interface IUserService extends IService<User> {
    int addUser(User user);
    UserDetails login(String username);
}
