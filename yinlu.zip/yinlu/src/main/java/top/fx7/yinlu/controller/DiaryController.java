package top.fx7.yinlu.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import top.fx7.yinlu.VO.R;
import top.fx7.yinlu.model.Diary;
import top.fx7.yinlu.service.IDiaryService;
import top.fx7.yinlu.service.ex.InsertException;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 人家故里
 * @since 2020-08-15
 */
@RestController
@RequestMapping("/api/v1/diary")
public class DiaryController {
    @Autowired
    IDiaryService diaryService;

    @GetMapping("getAll")
    public R<List<Diary>> getDiaries(){
        List<Diary> diaries = diaryService.getDiaries();
        return R.ok(diaries);
    }

    @PostMapping("/write")
    public R<Void> writeDiary(Diary diary){
        int rows = diaryService.addDiary(diary);
        if (rows!=1){
            throw new InsertException("写入diary记录错误");
        }
        return R.ok();
    }
}
