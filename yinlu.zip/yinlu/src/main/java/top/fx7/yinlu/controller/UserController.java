package top.fx7.yinlu.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import top.fx7.yinlu.VO.R;
import top.fx7.yinlu.model.User;
import top.fx7.yinlu.service.IUserService;
import top.fx7.yinlu.service.ex.InsertException;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 人家故里
 * @since 2020-08-15
 */
@RestController
@RequestMapping("/api/v1/user")
public class UserController {
    @Autowired
    IUserService userService;

    @PostMapping("addUser")
    public R<Void> addUser(User user){
        int rows = userService.addUser(user);
        if (rows !=1){
            throw new InsertException("创建用户错误");
        }
        return R.ok();
    }
}
